======================================================================================
Fix Palette Button Mod
======================================================================================
Based on the project FixPalette by Leandro Ascierto (https://www.vbforums.com/showthread.php?886349-FixPalette-Addin)
Mod by Shagratt:
 My goal was to have a floating color picker on the press of a button instead of replacing
 the standard one. This version dont replace the original FixPalette and can be used
 alongside it.
Also added:
+Color Preview with Right Mouse side by side with color under mouse (to compare colors)
+Changed the 5 color palettes (All with size of 200x130px)
+Show Web color code (#FF00FF)
+Allow input of color code
   Valid formats:
   255,255,255 : Decimal RGB
   #FFFFFF : Web standard
   #00FFFFFF or &H00FFFFFF: Web/VB6 with/without alpha)
   #FFF : Web Short Syntax
+Create gradient between white->selected  color (with right mouse button) -> black
+Bigger screen color selector with more zoom
+Memorize the last 10 selected colors and last palette used.

+17/06/21
You can view colors change on double click. just leave the focus on the name of the property
(not in the value field). Every color picked with double click will change the value and
reflect the change.
