=============================================================================================
Codefolding v1.1					By Pedro Aguirrezabal (Shagratt@ARG)
=============================================================================================
 This is an add-in to Add Codefolding like capabilities to VB6 IDE

 Unfortunately VB6 doesnt support codefolding so I came with an idea to mimic its functionality
 by relocating part of the code (Functions/Sub or Regions) towards the bottom of the file and 
 leaving a placeholder that can be expanded.

 I divide foldable foldable content into two types:

 -Function/Sub:
  They can be Folded without any problem. The project can be opened by anyone without the AddIn and
  be 100% compatible.

 -Regions:
  This are the user defined area (they can be created by selecting the lines and opening the context
  menu with the right mouse). Regions can be of three types:
  
  -Outer regions:
   Regions that have several Functions/Sub inside. Like before this leave a 100% compatible project. 
  -Outer region with declares/enums/type:
   This ones (usually at the top of the module) are automatically marked to unfold on run/compile.
  -Inner region:
   This are the regions inside functions.There is no limit on the number of sublevels that can be
   created. If folded they are automatically unfolded on run/compile and refolded after.      
   
   IMPORTANT!!!: Inner regions need to be padded and every region inside another need another extra level 
   of padding. Not respecting this rule may break your code.

   The last two groups needs the AddIn to be enabled only if they are Folded.
   An Unfolded project is still 100% compatible.

NOTES:
   -Sub/Function/Props need scope to be explicit ("Public Sub","Private Sub","Public Func...)
   -May fail on FULL COMPILE (CTRL+F5) when Regions are folded and VB6 is configured with 
    "General->Compile on demand" (Bug on VB6 IDE. Dont raise the addIn event)



Changelog
=========

v1.0 (03/06/21)
  +Initial release.

v1.1 (04/03/22)
  +Fixed app name also Changed a few default values
