===========================================================================================
Document Map v2.2                                    By Pedro Aguirrezabal (Shagratt@ARG)
===========================================================================================
It display graph colored representation of the current code window wich can be clicked to navigate from
one point of the code to another instantly
It shows what part of the code you're seeing in the editor.
Its flicker free!
It has checks to not redraw when there is no code/views changes (its fast and not cpu intensive)
Default Colors:
   -Grey: Normal code
   -Light Grey: Begin of sub/function
   -Green: Comments

Left Click jump to that part of code.
Right click brings a menu to add/remove marks:
Cause I dont know how to access the Flags/Breakpoints I added a few special delimiters
that draw visual clues on the Document Map. (Must be the first chars in the line, except TODO)

   '*-  = Full purple line
   '*1  = Red mark on the right
   '*2  = Yellow mark on the right
   '*3  = Cyan mark on the right
   'TODO: = Shorter green mark on the right

   (Marks are part of the code so, unlike bookmarks, they are saved)


!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
IMPORTANT!!!: Rename DATAVIEW.DLL extension in VB6.EXE folder to disable it 
	      This file is causing problems with disapearing icons because its bad coded and dont 
	      like when another app use the menu level to add buttons. 
	      This will disable the DataView (yellow icon) wich most people never use.
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


Use "Standard API Color Picker" by Elroy




Changelog
=========

v1.0 (24/07/19)
   +Basic version as proof of concept (it just 'works') and is my first AddIn. There is a lot
    of room for improvement.

v1.1 (26/07/19)
   +Change focus back to project so mousewheel works after clicking document map
   +Moving while keeping the mouse pressed allow smooth scrolling through the document map
   +Right mouse menu give option to set / remove marks
   +Codeview are now centered on the click
   +While mouse button held it show the name of Sub / Fuction in that part of code
   +Support for CodeSmart bookmarks

v1.2 (28/07/19)
   +Integrated in VB6 Ide (No more a floating on-top form)
   +Full analisys for marks (before was skipping lines if code was too big)
   +Reworked some logics for faster code
    
v1.3 (04/08/19)
   +Better drawing representation (with spaces, no more just lines)
   +No more double height lines on short documents (double line space instead)

v1.4 (06/08/19)
   +Added a refresh to the UserDocument after redrawing wich make it more responsive using a compiled dll while
    moving the mouse with the left button down.
   +Recicle AddIn toolbar menu (only useful if youre editing the addin and stop it without removing it from
    another proyect.

v1.5 (20/08/19)
   +Right mouse menu integration on VB Ide (to add marks)
   +New Toolbar Icon

v1.6 (06/12/19)
   +Added new button to clear inmediate window

v1.7 (07/06/21)
   +Added Codemap default region header/footer
   +Improve some colors a little. (more contrast on Function/Sub)
   +Fixed End Sub/Function draw with a line (should have been working before)
   +No more dependency on Office library
   +Selection is highlighted on the document map

v2.0 (16/06/21)
   +Added Zoom on right mouse menu over Documentmap with zoom level indication and reset.
    (Only available on large files and depending on documentmap window size)
   +New command bar to move up/down between marks 1,2,3
   +Added configuration screen
   +Added customizable colors
   +Found cause of IDE icons to disappearing (Finally!)

	Rename DATAVIEW.DLL extension in VB6.EXE folder to disable it. 
	Its the file causing problems with disapearing icons.

    IMPORTANT: If this happened to you, deleting the reg key "HKCU\Software\Microsoft\Visual 	Basic\6.0\UI" and reopening vb6 will restore the lost icons

   Improvements while dragging LMB over Documentmap:
   +Show procedure name near mouse always (before was only when declaration was visible on screen)
   +Full procedure highlight while moving
   +Show linenumber

v2.1 (xx/06/21) Unreleased
   +When zoomed can insta scroll anywhere moving with LMB on the right side
   +Add all butons with a delay so Codesmart not interfere with button placement

v2.2 (04/02/22)
   +Added integration with my CodeFolding AddIn (v1.1)
