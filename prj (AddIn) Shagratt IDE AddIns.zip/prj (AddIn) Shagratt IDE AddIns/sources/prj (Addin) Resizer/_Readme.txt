=================================================================================================
Resizer (v1.0)						    By Pedro Aguirrezabal (Shagratt@ARG)
=================================================================================================
Based on and compatible with Resizer from Edward Catchpole and changes made by PeYTaN

-Add a button to open a form resizer screen.
-Pick a control on the form, then choose how it will resize/move when screen resize
 (You dont need to add code in Form_Resize event, its all GUI based)
-Has a button to automatically add "ControlResizer.cls" to project if needed and the code
 for it on the form to use it. This file must be in the same folder as "ResizerAddIn.dll"
