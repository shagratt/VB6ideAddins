=================================================================================================
Resizer (v1.0)						    By Pedro Aguirrezabal (Shagratt@ARG)
=================================================================================================
Based on and compatible with Resizer from Edward Catchpole and changes made by PeYTaN

-Add a button to open a form resizer screen.
-Pick a control on the form, then choose how it will resize/move when screen resize
 (No more coded needed in Form_Resize event, its all GUI based)
-Has a button to automatically add "ControlResizer.cls" to project if needed and the code
 for it on the form to use it. This file must be in the same folder as "ResizerAddIn.dll"
-GUI autohide when form editor is not in focus



HOW TO USE IT:
==============

1) Enable the AddIn
2) Click the new button at menu level to open the Form Resizer Window.
   When opening it will scan your project and offer to add  
   "ControlResizer.cls" to it. This is the only file needed in your
   project to process the resizer data created from the GUI.
3) Select a control on the form designer and choose the resizing/reposition
   you want for that control. (Resize with form, anchor bottom right,etc.)
4) Repeat step 3 with all controls you want to automate
5) Press "Add VB Code to Form" so it add the necesary code in the form load/resize
   NOTE: This is needed only once per form where the Resizer AddIn was used! and 
   this also checks for "ControlResizer.cls" to be present in the project.


SPECIAL NOTE: On forms that show maximized in the Form_Load replace 
	Resizer.InitResizer Me, [Me.Width], [Me.Height] with the correct values of
	your form used in the Form Designer.
   

