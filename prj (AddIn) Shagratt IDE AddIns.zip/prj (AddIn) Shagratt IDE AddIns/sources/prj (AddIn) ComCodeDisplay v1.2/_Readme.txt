=============================================================================================
Comment Display+Highlight+Hotkeys v1.2                By Pedro Aguirrezabal (Shagratt@ARG)
=============================================================================================
 This is an add-in to display comments and code of user generated
 Functons/Methods/Properties and also some info from typelibs in the project

 It takes the text inside comments over the declarations and also from the menu
 Tools->Procedure Attributes or inside typelibs

 (optional) Also have extra hotkeys:
   CTRL+Q: Smart lines comment / uncomment
   CTRL+D: Duplicate Lines
   CTRL+SHIFT+UP and CTRL+SHIFT+DOWN: Move Up or Down selected lines

 (optional) Also has selection highlight on editor on all ocurrences of text/selection


 IMPORTANT: This is a WIA (Work In Progress) I'm releasing this AddIn as
            an unfinished project. Its working but I feel there is still some more
            polishing to do. Just dont have the time needed right now.

 NOTE: If highlighting a word doesnt seem to work try selecting another word and then
       reselecting the word you want to hihglight OR scroll the editor up/down to force
       re apply highlighting.

 Special thanks to Fafalone and LaVolpe for helping how to access typelibs data.



Changelog
=========

v0.8 (06/05/21)
  +Initial release.
v0.8b (07/05/21)
  +Highlight: Fixed default font values and without comment viewer
v0.8c (10/05/21)
  +Highlight: Fixed horizontal scrolling on editor
v0.8d (11/05/21)
  +Highlight: Fixed lines with ampersand ('&')
  +Removed reference to Office objects
v0.8e (12/05/21)
  +Fixed default VB6 to Courier New and not Times New Roman
   (for people who have never changed the font)
v1.0 (10/06/21)
  +Fixed ExtraHotkeys to work on all opened VB6 instances and not just one
v1.1 (26/08/21)
  +Fixed Loading, now support big groups with multiple projects
  +Comments with lines with separators like '======' (same char) are cut to display better
v1.2 (31/01/22)
  +Fixed Tooltip auto hide after the first time shown and causing focus steal from editor.
  +Removed unused reference to Common Controls 
